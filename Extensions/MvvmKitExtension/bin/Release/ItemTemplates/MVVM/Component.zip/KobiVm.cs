﻿using MvvmKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace $namespace$
{
    public class $itemname$ : ComponentBase
    {		
        #region Properties

        #endregion

        public $itemname$() 
        {
        }

        [InjectionMethod]
        public void Inject()
        {
        }

    }
}
